//

Ext.define('Shopware.apps.AvenFaxitems.view.detail.Window', {
    extend: 'Shopware.window.Detail',
    alias: 'widget.product-detail-window',
    title : '{s name=title}Article Details Faxorder{/s}',
    height: 420,
    width: 900
});
