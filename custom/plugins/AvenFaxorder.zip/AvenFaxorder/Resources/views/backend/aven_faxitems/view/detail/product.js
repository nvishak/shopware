//

Ext.define('Shopware.apps.AvenFaxitems.view.detail.Product', {
    extend: 'Shopware.model.Container',
    padding: 20,

    configure: function() {
        return {
            controller: 'AvenFaxitems'
        };
    }
});