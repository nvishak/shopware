// //
//
// Ext.define('Shopware.apps.AvenFaxorder.store.Customer', {
//     extend:'Shopware.store.Listing',
//
//     configure: function() {
//         return {
//             controller: 'AvenCustomer'
//         };
//     },
//
//     model: 'Shopware.apps.AvenFaxorder.model.Customer'
// });