// //
//
// Ext.define('Shopware.apps.AvenFaxorder.view.detail.Customer', {
//     extend: 'Shopware.model.Container',
//     padding: 20,
//
//     configure: function() {
//         return {
//             controller: 'AvenCustomer'
//         };
//     }
// });