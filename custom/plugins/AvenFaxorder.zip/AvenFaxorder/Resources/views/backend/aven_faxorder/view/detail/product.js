//

Ext.define('Shopware.apps.AvenFaxorder.view.detail.Product', {
    extend: 'Shopware.model.Container',
    padding: 20,

    configure: function() {
        return {
            controller: 'AvenFaxorder'
        };
    }
});