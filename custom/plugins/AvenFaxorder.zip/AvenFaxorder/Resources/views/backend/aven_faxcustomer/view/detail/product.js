//

Ext.define('Shopware.apps.AvenFaxcustomer.view.detail.product', {
    extend: 'Shopware.model.Container',
    padding: 20,

    configure: function() {
        return {
            controller: 'AvenFaxdetails'
        };
    }
});