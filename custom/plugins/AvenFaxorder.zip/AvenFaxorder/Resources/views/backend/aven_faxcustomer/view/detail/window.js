//

Ext.define('Shopware.apps.AvenFaxcustomer.view.detail.Window', {
    extend: 'Shopware.window.Detail',
    alias: 'widget.faxcustomer-detail-window',
    title : '{s name=title}Fax Order Customer{/s}',
    height: 420,
    width: 900
});
