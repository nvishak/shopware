//

Ext.define('Shopware.apps.AvenFaxcustomer.view.detail.Customer', {
    extend: 'Shopware.model.Container',
    padding: 20,

    configure: function() {
        return {
            controller: 'AvenFaxdetails'
        };
    }
});