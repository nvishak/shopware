//

Ext.define('Shopware.apps.AvenFaxdetails.view.detail.Window', {
    extend: 'Shopware.window.Detail',
    alias: 'widget.product-detail-window',
    title : '{s name=title}Fax Customer details{/s}',
    height: 420,
    width: 900
});
